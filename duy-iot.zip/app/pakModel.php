<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class pakModel extends Model
{
   protected $table='hocsinh'; 
   public $timestamps = false;
}
