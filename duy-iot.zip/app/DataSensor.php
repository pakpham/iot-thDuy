<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataSensor extends Model
{
    protected $table = 'data_sensor';
}
